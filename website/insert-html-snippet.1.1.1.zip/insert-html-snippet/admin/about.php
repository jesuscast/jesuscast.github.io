<style>
</style>

<h1 style="visibility: visible;">Insert HTML Snippet (V <?php echo xyz_ihs_plugin_get_version(); ?>)</h1>
Integrate HTML code seamlessly to your wordpress. This plugin lets you generate a shortcode corresponding
to any random HTML  code be is javascript, ad codes, vide embedding codes or any raw  HTML. The shortcodes
can be used in your pages, posts and widgets.  Insert HTML Snippet is developed and maintained by
<a href="http://xyzscripts.com">xyzscripts</a>
.


<br />
<h2>Features</h2>

<div>
	<p></p>

	<div style="float: left;">
	
	
<ul>	
<li>Convert HTML snippets to shortcodes</li>
<li>Support for shortcodes in widgets</li>
<li>Dropdown menu in TinyMCE editor to pick snippets easily</li>
</ul>


	</div>



</div>




<div style="clear: both;"></div>


